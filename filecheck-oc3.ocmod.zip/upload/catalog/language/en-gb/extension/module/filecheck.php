<?php
$_[''] = ''; // required placeholder
